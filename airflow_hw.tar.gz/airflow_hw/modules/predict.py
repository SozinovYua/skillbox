from datetime import datetime
import glob
import json
import dill
import pandas as pd
from pydantic import BaseModel


def predict():
    with open('/home/yuri/airflow/airflow_hw/airflow_hw/data/models/cars_pipe_202210151819.pkl', 'rb') as file:
        model = dill.load(file)
        for filename in glob.glob('/home/yuri/airflow/airflow_hw/airflow_hw/data/test/*.json'):
            with open(filename, 'r', encoding='utf-8') as fin:
                form = json.load(fin)
                df = pd.DataFrame.from_dict([form])
                y = model.predict(df)
                x = {'car.id': df.id, 'pred': y}
                df_for_join = pd.DataFrame(list(x.items()), columns=['id','pred'])
            #df_prediction = pd.concat([df_for_join])
            df_for_join.to_csv(f'/home/yuri/airflow/airflow_hw/airflow_hw/data/predictions/predictions_{datetime.now().strftime("%Y%m%d%H%M")}.csv')


if __name__ == '__main__':
    predict()